<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="32rogues" tilewidth="32" tileheight="32" tilecount="442" columns="17">
 <image source="tiles.png" width="544" height="832"/>
</tileset>
