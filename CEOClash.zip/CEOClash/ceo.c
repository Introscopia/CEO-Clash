#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include <SDL.h>
#include <SDL_image.h>
#include "basics.h"
#include "vec2d.h"
#include "transform.h"




typedef struct {

    int direcao;
    int pulo;

    vec2d pos;
    vec2d vel;
    SDL_FRect hitbox;
    float altura_agachada;

    bool no_ar;
    bool no_controle;// true = estou no controle do meu corpo, 
                     // false = meu corpo foi arremessado por forcas externas

    float walkspeed;
    float jumppower;


} Fighter;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~O~~~~~~~~~~| M A I N |~~~~~~~~~~~O~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int main(int argc, char *argv[]){

    SDL_Window *window;
    SDL_Renderer *R;
    int width = 600;
    int height = 400;
    int cx, cy;
    int loop = 1;


    if( !SDL_Init(SDL_INIT_VIDEO) ){
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't initialize SDL: %s", SDL_GetError());
        return 3;
    }
    if( !SDL_CreateWindowAndRenderer( "CEO_Clash", width, height, 
                                      SDL_WINDOW_RESIZABLE | SDL_WINDOW_MAXIMIZED, 
                                      &window, &R ) ){
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't create window and renderer: %s", SDL_GetError());
        return 3;
    }
    SDL_GetWindowSize( window, &width, &height );
    cx = width / 2;
    cy = height / 2;

    // prime the random number generator
    SDL_srand(0);

    Transform T = (Transform){256,256,cx,cy,1,1};
    int scaleI = 0;


    float WALL_L = 0;
    float WALL_R = width;
    float FLOOR_Y = height - 100;
    

    Fighter P1 = {0};
    P1.pos = v2d( 100, FLOOR_Y );
    P1.hitbox.w = 200;
    P1.hitbox.h = 350;
    P1.hitbox.x = P1.pos.x - 0.5 * P1.hitbox.w;
    P1.hitbox.y = P1.pos.y - P1.hitbox.h;
    P1.walkspeed = 5;
    P1.jumppower = -20;
    bool p1u, p1d, p1l, p1r; // up down left right

    
    //our desired frame period
    int frame_period = SDL_roundf( 1000 / 60.0 );

    SDL_Log("<<Entering Loop>>");
    while ( loop ) { //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> L O O P <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        
        SDL_Event event;
        while( SDL_PollEvent(&event) ){
            switch (event.type) {
                case SDL_EVENT_QUIT:
                    loop = 0;
                    break;
                case SDL_EVENT_KEY_DOWN:
                         if( event.key.key == 'w' ) p1u = 1;
                    else if( event.key.key == 's' ) p1d = 1;
                    else if( event.key.key == 'a' ) p1l = 1;
                    else if( event.key.key == 'd' ) p1r = 1;
                    break;
                case SDL_EVENT_KEY_UP:
                         if( event.key.key == 'w' ) p1u = 0;
                    else if( event.key.key == 's' ) p1d = 0;
                    else if( event.key.key == 'a' ) p1l = 0;
                    else if( event.key.key == 'd' ) p1r = 0;
                    break;
            }
        }

        SDL_SetRenderDrawColor( R, 200,200,200,255 );
        SDL_RenderClear(R);

        SDL_SetRenderDrawColor( R, 0,0,0,255 );
        SDL_RenderLine( R, 0, FLOOR_Y, width, FLOOR_Y );


        vec2d desloc = (vec2d){0};
        if( p1l ){
            desloc.x = -1;
        }
        if( p1r ){
           desloc.x = 1;
        }
        if( p1u ){
            if( !(P1.no_ar)  ){// previne double jump
                P1.vel = v2d( 0, P1.jumppower );
                P1.no_ar = true;
                P1.no_controle = true;
            }
        }
        if( p1d ){
            //P1.hitbox.h = P1.altura_agachada;
            
        }
        
        if( P1.no_ar ){
            if( P1.no_controle ){
                P1.pos.x += desloc.x * P1.walkspeed;
                P1.direcao = desloc.x;
            }
            P1.pos.y += P1.vel.y;
            P1.vel.y += 1;

            if( P1.pos.y > FLOOR_Y ){
                P1.pos.y = FLOOR_Y;
                P1.no_ar = false;
            }
        }
        else{// no chao
            P1.pos.x += desloc.x * P1.walkspeed;
            P1.direcao = desloc.x;
        }

        if( P1.pos.x - 0.5 * P1.hitbox.w < WALL_L ){// colisao com a parede Left
            P1.pos.x = WALL_L + 0.5 * P1.hitbox.w;
        }
        if( P1.pos.x + 0.5 * P1.hitbox.w > WALL_R ){// colisao com a parede Left
            P1.pos.x = WALL_R - 0.5 * P1.hitbox.w;
        }

        P1.hitbox.x = P1.pos.x - 0.5 * P1.hitbox.w;
        P1.hitbox.y = P1.pos.y - P1.hitbox.h;

        SDL_SetRenderDrawColor( R, 0,0,255,255 );
        SDL_RenderRect( R, &(P1.hitbox) );


        // throw things up onscreen
        SDL_RenderPresent(R);
        // try to maintain constant framerate
        SDL_framerateDelay( frame_period );

    }//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> / L O O P <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    SDL_DestroyRenderer(R);
    SDL_DestroyWindow(window);

    SDL_Quit();

    return 0;
}

